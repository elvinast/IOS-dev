//
//  DeleteAlarm.swift
//  midtermProject
//
//  Created by Эльвина on 12.03.2021.
//

import Foundation

protocol DeleteAlarm {
    func deleteAlarm(index: Int)
}
