//
//  ChangeAlarm.swift
//  midtermProject
//
//  Created by Эльвина on 12.03.2021.
//

import Foundation

protocol ChangeAlarm {
    func changeAlarm(time: String, description: String, index: Int)
}
